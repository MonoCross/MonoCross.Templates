﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MonoCross.Navigation;
using $rootnamespace$.Controllers;

namespace $rootnamespace$
{
    public class $safeitemname$ : MXApplication
    {
        public override void OnAppLoad()
        {
            // set application title
            // example: Title = "$itemname$";

            // add controllers to navigation map
            // example: NavigationMap.Add("", new Controllers.MyController());

            // set navigate on load endpoint
            // example: NavigateOnLoad = "";
        }
    }
}
