﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof($safeprojectname$.Startup))]
namespace HelloWorld.Webkit
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app) { }
    }
}
